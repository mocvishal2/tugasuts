import 'package:flutter/material.dart';
import 'pack1.dart';
import 'pack2.dart';
import 'login.dart';
import 'conten.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});
  static const appTitle = 'Wisata Di Tenggarong';
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'appTitle',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          brightness: Brightness.light,
          canvasColor: Colors.transparent,
          primarySwatch: Colors.yellow,
          fontFamily: "Montserrat",
        ),
        home: login(),
        routes: {'home_page': (context) => login()});
  }
}
