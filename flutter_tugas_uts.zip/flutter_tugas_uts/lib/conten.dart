import 'package:flutter/material.dart';
import 'pack1.dart';
import 'pack2.dart';
import 'data/data1.dart';
import 'data/data2.dart';
import 'data/data3.dart';

class MyHomePage extends StatelessWidget {
  const MyHomePage({super.key, required this.title});

  final String title;

  @override
  Widget build(BuildContext context) {
    AppBar myAppbar = AppBar(title: Text(title));

    final double heightDevice = MediaQuery.of(context).size.height;
    final double bodyApp = heightDevice -
        myAppbar.preferredSize.height -
        MediaQuery.of(context).padding.top;
    final double widthDevice = MediaQuery.of(context).size.width;
    return Scaffold(
      appBar: AppBar(title: Text(title)),
      body: Container(
        width: double.infinity,
        child: ListView(scrollDirection: Axis.vertical, children: [
          AspectRatio(
            aspectRatio: 4 / 6,
            child: Container(
              margin: EdgeInsets.only(right: 20),
              child: Align(
                alignment: Alignment.bottomCenter,
                child: TextButton(
                  child: Text(
                    'Jembatan Repo-Repo',
                    style: TextStyle(
                      fontSize: 30,
                    ),
                  ),
                  onPressed: () {
                    // Update the state of the app

                    // Then close the drawer
                    Navigator.of(context)
                        .push(MaterialPageRoute(builder: (context) => Data1()));
                    ;
                  },
                ),
              ),
              decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage('assets/imeg1.png'), fit: BoxFit.cover),
              ),
            ),
          ),
          AspectRatio(
            aspectRatio: 4 / 6,
            child: Container(
              margin: EdgeInsets.only(right: 20),
              child: Align(
                alignment: Alignment.bottomCenter,
                child: TextButton(
                  child: Text(
                    'Museum Mulawarman',
                    style: TextStyle(
                      fontSize: 30,
                    ),
                  ),
                  onPressed: () {
                    // Update the state of the app

                    // Then close the drawer
                    Navigator.of(context)
                        .push(MaterialPageRoute(builder: (context) => Data2()));
                    ;
                  },
                ),
              ),
              decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage('assets/imeg2.png'), fit: BoxFit.cover),
              ),
            ),
          ),
          AspectRatio(
            aspectRatio: 4 / 6,
            child: Container(
              margin: EdgeInsets.only(right: 20),
              child: Align(
                alignment: Alignment.bottomCenter,
                child: TextButton(
                  child: Text(
                    'Ladang Budaya',
                    style: TextStyle(
                      fontSize: 30,
                    ),
                  ),
                  onPressed: () {
                    // Update the state of the app

                    // Then close the drawer
                    Navigator.of(context)
                        .push(MaterialPageRoute(builder: (context) => Data3()));
                    ;
                  },
                ),
              ),
              decoration: BoxDecoration(
                image: DecorationImage(
                    image: AssetImage('assets/imeg3.png'), fit: BoxFit.cover),
              ),
            ),
          ),
        ]),
      ),
      drawer: Drawer(
        // Add a ListView to the drawer. This ensures the user can scroll
        // through the options in the drawer if there isn't enough vertical
        // space to fit everything.
        child: ListView(
          // Important: Remove any padding from the ListView.
          padding: EdgeInsets.zero,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(
                color: Colors.lightGreen,
              ),
              child: Text('menu'),
            ),
            ListTile(
              title: Text("item 1"),
              onTap: () {
                // Update the state of the app

                // Then close the drawer
                Navigator.of(context)
                    .push(MaterialPageRoute(builder: (context) => PageSatu()));
                ;
              },
            ),
            ListTile(
              title: const Text('Item 2'),
              onTap: () {
                // Update the state of the app
                // ...
                // Then close the drawer
                Navigator.of(context)
                    .push(MaterialPageRoute(builder: (context) => PageDua()));
              },
            ),
          ],
        ),
      ),
    );
  }
}
