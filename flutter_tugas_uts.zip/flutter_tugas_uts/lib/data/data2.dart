import 'package:flutter/material.dart';

class Data2 extends StatelessWidget {
  const Data2({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("title")),
      body: Column(
        children: <Widget>[
          Image.asset('imeg2.png'),
          Text(
            'Museum Mulawarman',
            style: TextStyle(fontSize: 24, fontFamily: "Serif", height: 2.0),
          ),
          Text(
              'Museum Mulawarman adalah sebuah museum di kota Tenggarong, Provinsi Kalimantan Timur, Indonesia. Museum ini merupakan bekas istana dari Kesultanan Kutai Kartanegara yang dibangun pada tahun 1936.')
        ],
        // child: Row(children: [
        //   Column(mainAxisAlignment: MainAxisAlignment.start, children: [
        //     Container(
        //         height: 500,
        //         width: 500,
        //         margin: EdgeInsets.all(20),
        //         decoration: BoxDecoration(
        //             image: DecorationImage(
        //           image: AssetImage('assets/imeg1.png'),
        //         )))
        //   ]),
        //   Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        //     Text(
        //       'judul',
        //       style: TextStyle(
        //         fontSize: 20,
        //       ),
        //     ),
        //   ]),
        //   Column(mainAxisAlignment: MainAxisAlignment.start, children: [
        //     Text(
        //       'text',
        //       style: TextStyle(
        //         fontSize: 20,
        //       ),
        //     ),
        //   ]),
        //   Row(
        //     children: [
        //       Icon(Icons.star, color: Colors.green[500]),
        //       Icon(Icons.star, color: Colors.green[500]),
        //       Icon(Icons.star, color: Colors.green[500]),
        //       const Icon(Icons.star, color: Colors.black),
        //       const Icon(Icons.star, color: Colors.black),
        //     ],
        //   )
        // ]),
        // child: Text(
        //   'gunung1',
        //   style: TextStyle(
        //     fontSize: 20,
        //   ),
        // ),
      ),
      // decoration: BoxDecoration(
      //   image: DecorationImage(
      //       image: AssetImage('assets/imeg1.png'), fit: BoxFit.cover),
      /*Image.asset(
              'assets/imeg1.png',
              height: 200,
              width: 200,
              ),*/
    );
  }
}
