import 'package:flutter/material.dart';

class Data3 extends StatelessWidget {
  const Data3({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("title")),
      body: Column(
        children: <Widget>[
          Image.asset('imeg3.png'),
          Text(
            'Ladang Budaya',
            style: TextStyle(fontSize: 24, fontFamily: "Serif", height: 2.0),
          ),
          Text(
              'Ladang Budaya, atau yang lebih sering disebut Ladaya, merupakan salah satu tempat wisata di Tenggarong yang cukup terkenal. Spot liburan ini dapat Anda temukan di Jalan H. Bachrin Seman, RT 12, Mangkurawang, Tenggarong, Kabupaten Kutai Kartanegara, Kalimantan Timur. Selain menawarkan destinasi untuk refreshing, Ladaya juga memiliki penginapan unik berbentuk rumah kayu.')
        ],
        // child: Row(children: [
        //   Column(mainAxisAlignment: MainAxisAlignment.start, children: [
        //     Container(
        //         height: 500,
        //         width: 500,
        //         margin: EdgeInsets.all(20),
        //         decoration: BoxDecoration(
        //             image: DecorationImage(
        //           image: AssetImage('assets/imeg1.png'),
        //         )))
        //   ]),
        //   Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        //     Text(
        //       'judul',
        //       style: TextStyle(
        //         fontSize: 20,
        //       ),
        //     ),
        //   ]),
        //   Column(mainAxisAlignment: MainAxisAlignment.start, children: [
        //     Text(
        //       'text',
        //       style: TextStyle(
        //         fontSize: 20,
        //       ),
        //     ),
        //   ]),
        //   Row(
        //     children: [
        //       Icon(Icons.star, color: Colors.green[500]),
        //       Icon(Icons.star, color: Colors.green[500]),
        //       Icon(Icons.star, color: Colors.green[500]),
        //       const Icon(Icons.star, color: Colors.black),
        //       const Icon(Icons.star, color: Colors.black),
        //     ],
        //   )
        // ]),
        // child: Text(
        //   'gunung1',
        //   style: TextStyle(
        //     fontSize: 20,
        //   ),
        // ),
      ),
      // decoration: BoxDecoration(
      //   image: DecorationImage(
      //       image: AssetImage('assets/imeg1.png'), fit: BoxFit.cover),
      /*Image.asset(
              'assets/imeg1.png',
              height: 200,
              width: 200,
              ),*/
    );
  }
}
