import 'package:flutter/material.dart';

class Data1 extends StatelessWidget {
  const Data1({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("title")),
      body: Column(
        children: <Widget>[
          Image.asset('imeg1.png'),
          Text(
            'Jembatan Repo-Repo ',
            style: TextStyle(fontSize: 24, fontFamily: "Serif", height: 2.0),
          ),
          Text(
              'Jembatan Repo-Repo adalah jembatan khusus pejalan kaki yang membentang di atas Sungai Mahakam dan menghubungkan daratan kota Tenggarong dengan Pulau Kumala, Provinsi Kalimantan Timur. Jembatan ini resmi dibuka oleh Bupati Kutai Kartanegara Rita Widyasari pada tanggal 22 Maret 2016.')
        ],
      ),
    );
  }
}
