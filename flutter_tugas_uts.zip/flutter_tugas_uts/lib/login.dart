import 'package:flutter/material.dart';
import 'pack1.dart';
import 'pack2.dart';
import 'conten.dart';

TextEditingController getUser = new TextEditingController();
TextEditingController getPass = new TextEditingController();
final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();

class login extends StatelessWidget {
  const login({
    Key? key,
  }) : super(key: key);
  static const appTitle = 'Wisata Di Tenggarong';
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      body: Column(children: [
        SizedBox(height: 200),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextFormField(
            controller: getUser,
            decoration: InputDecoration(
              labelText: 'Username',
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
              suffixIcon: Icon(
                Icons.error,
              ),
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: TextFormField(
            controller: getPass,
            decoration: InputDecoration(
              labelText: 'Password',
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(30)),
              suffixIcon: Icon(
                Icons.error,
              ),
            ),
          ),
        ),
        Row(
          children: [
            TextButton(
              onPressed: () {
                String user = 'vishal';
                String pass = '1234';
                if (getUser.text.length == 0) {
                  final errorUser = SnackBar(
                    content: Text('Username tidak boleh kosong!'),
                    duration: Duration(seconds: 2),
                  );
                  ScaffoldMessenger.of(context)
                      .showSnackBar(SnackBar(content: Text("Login failed")));
                } else if (getPass.text.length == 0) {
                  final errorUser = SnackBar(
                    content: Text('Password tidak boleh kosong!'),
                    duration: Duration(seconds: 2),
                  );
                  ScaffoldMessenger.of(context)
                      .showSnackBar(SnackBar(content: Text("Login failed")));
                } else if (getUser.text == user && getPass.text == pass) {
                  final errorUser = SnackBar(
                    content: Text('Selamat datang user: ' + getUser.text),
                    duration: Duration(seconds: 2),
                  );
                  ScaffoldMessenger.of(context)
                      .showSnackBar(SnackBar(content: Text("sukses")));
                  //delay to Home page

                  Navigator.push(
                      context,
                      MaterialPageRoute(
                          builder: (context) => MyHomePage(title: appTitle)));
                } else {
                  final errorUser = SnackBar(
                    content: Text('Cek kembali input anda!'),
                    duration: Duration(seconds: 2),
                  );
                  ScaffoldMessenger.of(context)
                      .showSnackBar(SnackBar(content: Text("Login failed")));
                }
              },
              child: Text(
                "Log In",
                style: TextStyle(
                    color: Color.fromARGB(251, 56, 6, 238).withOpacity(0.6)),
              ),
            ),
          ],
        )
      ]),
    );
  }
}
